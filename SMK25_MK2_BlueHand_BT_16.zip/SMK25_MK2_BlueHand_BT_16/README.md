# M-VAVE SMK-25 MK2 → Ableton Live Blue Hand Bluetooth 16 Parameter

この版は、動作していたBluetooth版 `UserConfiguration.txt` を基準に、
Blue Hand / Device Controlだけを16パラメーター対応へ単純拡張した版です。

## 変更点

- Parameter 1〜8 : CC20〜27
- Parameter 9〜16 : CC28〜35
- すべて MIDI Ch.1
- Encoder Map Mode : Absolute
- Mixer / Transport / Pads : これまでどおり無効
- Bluetoothポート名 : 元の動作版と同じ `SMK25II-Bt-MIDI`
- `SMK25II-Bt-DAW` はBlue Hand用には使用しません

## SMK-25 MK2側

Live側では次のCCを待ちます。

| Parameter | CC | MIDI Ch. |
|---:|---:|---:|
| 1 | 20 | 1 |
| 2 | 21 | 1 |
| 3 | 22 | 1 |
| 4 | 23 | 1 |
| 5 | 24 | 1 |
| 6 | 25 | 1 |
| 7 | 26 | 1 |
| 8 | 27 | 1 |
| 9 | 28 | 1 |
| 10 | 29 | 1 |
| 11 | 30 | 1 |
| 12 | 31 | 1 |
| 13 | 32 | 1 |
| 14 | 33 | 1 |
| 15 | 34 | 1 |
| 16 | 35 | 1 |

8個の物理ノブを2バンクで使う場合は、
第1バンクでCC20〜27、第2バンクでCC28〜35を送るようにしてください。

## Bluetooth接続

Windows + Sinco Connectorでは、Blue Hand用Inputは通常のBluetooth MIDI / CC側を使います。

```text
SMK25II-Bt-MIDI   ← Blue Hand用
SMK25II-Bt-DAW    ← DAW / Mackie側
```

実際のポート名が違う場合は、Live側でCC20〜35が届くBluetooth MIDIポートを手動選択してください。

## 設置

今回実際に認識できた構造に合わせ、READMEとUserConfiguration.txtを同じ階層にしています。

```text
...\Live 12.3.2\Preferences\User Remote Scripts\
└─ SMK25_MK2_BlueHand_BT_16\
   ├─ README.md
   └─ UserConfiguration.txt
```

Liveを完全終了した状態でフォルダごと配置し、Liveを起動します。

環境設定 → Link, Tempo & MIDI で、

```text
Control Surface : SMK25_MK2_BlueHand_BT_16
Input           : Bluetoothの通常MIDI / CCポート
Output          : 同じBluetooth MIDIポート、またはNone
```

を選択してください。

## 補足

この版ではBankボタン、Mixer、Transportなどは追加していません。
あくまで16個のDevice Control CCを直接Blue Handへ渡すシンプル版です。
