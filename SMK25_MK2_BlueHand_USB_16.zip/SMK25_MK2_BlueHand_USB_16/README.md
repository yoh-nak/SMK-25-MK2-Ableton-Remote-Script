# M-VAVE SMK-25 MK2 → Ableton Live Blue Hand USB 16 Parameter

この版は、動作していたUSB用 `UserConfiguration.txt` を基準に、
Blue Hand / Device Controlだけを16パラメーター対応へ単純拡張した版です。

## 変更点

- Parameter 1〜8 : CC20〜27
- Parameter 9〜16 : CC28〜35
- すべて MIDI Ch.1
- Encoder Map Mode : Absolute
- Mixer / Transport / Pads : これまでどおり無効
- USBポート名 : 元の動作版と同じ `SMK25II MIDI 2`

## SMK-25 MK2側

Live側では次のCCを待ちます。

| Parameter | CC | MIDI Ch. |
|---:|---:|---:|
| 1 | 20 | 1 |
| 2 | 21 | 1 |
| 3 | 22 | 1 |
| 4 | 23 | 1 |
| 5 | 24 | 1 |
| 6 | 25 | 1 |
| 7 | 26 | 1 |
| 8 | 27 | 1 |
| 9 | 28 | 1 |
| 10 | 29 | 1 |
| 11 | 30 | 1 |
| 12 | 31 | 1 |
| 13 | 32 | 1 |
| 14 | 33 | 1 |
| 15 | 34 | 1 |
| 16 | 35 | 1 |

SMK-25 MK2側の第2セット / 第2バンク / 別操作子が別のCCを送る場合は、
`Encoder9`〜`Encoder16` の8行だけ実際のCC番号に合わせて変更してください。

## 設置

今回確認できた配置に合わせ、READMEとUserConfiguration.txtを同じ階層にしています。

```text
...\Live 12.3.2\Preferences\User Remote Scripts\
└─ SMK25_MK2_BlueHand_USB_16\
   ├─ README.md
   └─ UserConfiguration.txt
```

Liveを完全終了した状態でフォルダごと配置し、Liveを起動します。

環境設定 → Link, Tempo & MIDI で、

```text
Control Surface : SMK25_MK2_BlueHand_USB_16
Input           : USBの通常CCポート
Output          : 同じUSBポート、またはNone
```

を選択してください。

## 補足

Live 12のUser Remote Scriptでは Encoder1〜Encoder16 を使うと、
選択中Deviceの最大16パラメーターを同時に対象にできます。

この版ではBankボタン機能は追加していません。
あくまで「16個のDevice Control CCを直接使う」シンプル版です。
